import { Component } from '@angular/core';
import { VehicleCardListComponent } from '../vehicle-card-list/vehicle-card-list.component';

@Component({
  selector: 'app-vehicles-section',
  imports: [VehicleCardListComponent],
  templateUrl: './vehicles-section.component.html',
  styles: ``
})
export class VehiclesSectionComponent {

}
