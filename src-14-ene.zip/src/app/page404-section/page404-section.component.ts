import { Component } from '@angular/core';

@Component({
  selector: 'app-page404-section',
  imports: [],
  templateUrl: './page404-section.component.html',
  styles: ``
})
export class Page404SectionComponent {

}
