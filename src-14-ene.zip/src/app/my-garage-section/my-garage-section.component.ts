import { Component } from '@angular/core';
import { GarageListComponent } from '../my-garage-list/my-garage-list.component';

@Component({
  selector: 'app-garage-section',
  imports: [GarageListComponent],
  templateUrl: './garage-section.component.html',
  styles: ``
})
export class GarageSectionComponent {

}